import tkinter as tk
from tkinter import messagebox
import socket
import subprocess
import os

username_entry = None
password_entry = None
login_window = None

def send_command(command):
    client.send(command.encode())
    response = client.recv(1024).decode()
    messagebox.showinfo("DSES", response)

def open_gnuradio_companion():
    grc_path = "C:/Users/faalk/jam.grc"  # Change this path accordingly
    if os.path.exists(grc_path):
        try:
            subprocess.Popen(["C:/Users/faalk/radioconda/python.exe", 
                              "C:/Users/faalk/radioconda/cwp.py", 
                              "C:/Users/faalk/radioconda", 
                              "C:/Users/faalk/radioconda/Scripts/gnuradio-companion.exe", 
                              grc_path])
        except FileNotFoundError:
            messagebox.showerror("Error", "GNU Radio Companion (GRC) executable not found.")
    else:
        messagebox.showerror("Error", "The specified GRC file does not exist.")

def login():
    global username_entry, password_entry, login_window
    username = username_entry.get()
    password = password_entry.get()
    if username in ["maha", "fatima", "salma"] and password == "DSES":
        login_window.withdraw()  # Hide the login window
        create_main_window()
    else:
        messagebox.showerror("Error", "Invalid username or password")

def create_main_window():
    main_window = tk.Toplevel()
    main_window.title("Drone Security Enhancement System")

    # Center the main window
    window_width = 400
    window_height = 200
    screen_width = main_window.winfo_screenwidth()
    screen_height = main_window.winfo_screenheight()
    x = (screen_width - window_width) // 2
    y = (screen_height - window_height) // 2
    main_window.geometry(f"{window_width}x{window_height}+{x}+{y}")

    # Create label for main window
    label = tk.Label(main_window, text="Drone Security Enhancing System", font=("Times New Roman", 16, "bold"), fg="blue")
    label.pack(pady=20)

    # Create buttons with increased width
    buttons_frame = tk.Frame(main_window)
    buttons_frame.pack()

    gps_button = tk.Button(buttons_frame, text="GPS Data", command=lambda: send_command("GPS"), width=15, bg="orange", fg="white")
    gps_button.grid(row=0, column=0, padx=10, pady=5)

    oob_button = tk.Button(buttons_frame, text="Out of Boundaries", command=lambda: send_command("OOB"), width=15, bg="green", fg="white")
    oob_button.grid(row=0, column=1, padx=10, pady=5)

    jamming_button = tk.Button(buttons_frame, text="Jamming Signal", command=open_gnuradio_companion, width=15, bg="purple", fg="white")
    jamming_button.grid(row=0, column=2, padx=10, pady=5)

    # Add exit button
    exit_button = tk.Button(main_window, text="exit", command=recreate_login_window)
    exit_button.place(relx=1, rely=1, anchor='se', x=-10, y=-30)

    # Add trademark label
    trademark_label = tk.Label(main_window, text="SDP2324 - CE21 @Qatar University", font=("Times New Roman", 8), bg="white")
    trademark_label.pack(side="bottom", fill="x", padx=10, pady=10)

def recreate_login_window():
    global login_window
    if login_window:
        login_window.deiconify()  # Show the login window again
    else:
        login_window = tk.Tk()
        login_window.title("Login")

        # Set the background color of the login window to white
        login_window.configure(bg="white")

        # Center the login window 
        window_width = 500
        window_height = 300
        screen_width = login_window.winfo_screenwidth()
        screen_height = login_window.winfo_screenheight()
        x = (screen_width - window_width) // 2
        y = (screen_height - window_height) // 2
        login_window.geometry(f"{window_width}x{window_height}+{x}+{y}")

        # Load the image
        image_path = "queng.png"  # Change this to the path of your image file
        logo = tk.PhotoImage(file=image_path)

        # Create widgets for login window
        image_label = tk.Label(login_window, image=logo, bg="white")
        image_label.grid(row=0, column=0, columnspan=2, padx=5, pady=5)

        authorization_label = tk.Label(login_window, text="Authorization required", font=("Times New Roman", 12, "bold"), fg="blue", bg="light grey")
        authorization_label.grid(row=1, column=0, columnspan=2, padx=5, pady=5)

        global username_entry, password_entry
        username_label = tk.Label(login_window, text="Username:", fg="blue", bg="white")
        username_label.grid(row=2, column=0, padx=5, pady=5)

        username_entry = tk.Entry(login_window)
        username_entry.grid(row=2, column=1, padx=5, pady=5)

        password_label = tk.Label(login_window, text="Password:", fg="blue", bg="white")
        password_label.grid(row=3, column=0, padx=5, pady=5)

        password_entry = tk.Entry(login_window, show="*")
        password_entry.grid(row=3, column=1, padx=5, pady=5)

        login_button = tk.Button(login_window, text="Login", command=login, width=8, fg="red", bg="white", font=("Times New Roman", 10, "bold"))
        login_button.grid(row=5, column=1, sticky="e", padx=5, pady=5)

    login_window.mainloop()

client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client.connect(('192.168.8.5', 80))

recreate_login_window()